param(
    [Parameter(Mandatory = $true)][int]$RevitProcessId,
    [Parameter(Mandatory = $true)][string]$PackagePath,
    [Parameter(Mandatory = $true)][string]$ExpectedSha256,
    [Parameter(Mandatory = $true)][string]$TargetAddinsRoot,
    [Parameter(Mandatory = $true)][string]$AddinFile,
    [Parameter(Mandatory = $true)][string]$InstallFolder,
    [Parameter(Mandatory = $true)][string]$Version,
    [Parameter(Mandatory = $true)][string]$LogPath,
    [switch]$Silent
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog([string]$Message) {
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -LiteralPath $LogPath -Value "[$stamp] $Message" -Encoding UTF8
}

function Show-Result([string]$Title, [string]$Message, [bool]$IsError) {
    if ($Silent) {
        return
    }
    try {
        Add-Type -AssemblyName PresentationFramework
        $icon = if ($IsError) {
            [System.Windows.MessageBoxImage]::Error
        }
        else {
            [System.Windows.MessageBoxImage]::Information
        }
        [System.Windows.MessageBox]::Show(
            $Message,
            $Title,
            [System.Windows.MessageBoxButton]::OK,
            $icon) | Out-Null
    }
    catch {
        # The log remains available when a desktop message cannot be shown.
    }
}

$workRoot = Join-Path ([System.IO.Path]::GetDirectoryName($LogPath)) ("stage-" + [guid]::NewGuid().ToString("N"))
$extractRoot = Join-Path $workRoot "extract"
$targetFolder = Join-Path $TargetAddinsRoot $InstallFolder
$targetManifest = Join-Path $TargetAddinsRoot $AddinFile
$sourceFolder = Join-Path $extractRoot $InstallFolder
$sourceManifest = Join-Path $extractRoot $AddinFile
$backupSuffix = (Get-Date).ToString("yyyyMMdd-HHmmss")
$backupFolder = "$targetFolder.backup-$backupSuffix"
$backupManifest = "$targetManifest.backup-$backupSuffix"
$folderBackedUp = $false
$manifestBackedUp = $false

try {
    New-Item -ItemType Directory -Path ([System.IO.Path]::GetDirectoryName($LogPath)) -Force | Out-Null
    Set-Content -LiteralPath $LogPath -Value "" -Encoding UTF8
    Write-UpdateLog "RA BIM update $Version started in detached mode."
    Write-UpdateLog "Verifying and staging the package while Revit is still open."
    if (-not (Test-Path -LiteralPath $PackagePath)) {
        throw "Downloaded package was not found: $PackagePath"
    }
    $actualHash = (Get-FileHash -LiteralPath $PackagePath -Algorithm SHA256).Hash
    if (-not $actualHash.Equals($ExpectedSha256, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Package SHA-256 verification failed."
    }

    New-Item -ItemType Directory -Path $extractRoot -Force | Out-Null
    Expand-Archive -LiteralPath $PackagePath -DestinationPath $extractRoot -Force
    if (-not (Test-Path -LiteralPath (Join-Path $sourceFolder "RA_BIM_STR.dll"))) {
        throw "The update package does not contain $InstallFolder\RA_BIM_STR.dll."
    }
    if (-not (Test-Path -LiteralPath $sourceManifest)) {
        throw "The update package does not contain $AddinFile."
    }

    Write-UpdateLog "Package staged successfully. Waiting for every Revit process to close."
    while (@(Get-Process -Name "Revit" -ErrorAction SilentlyContinue).Count -gt 0) {
        Start-Sleep -Milliseconds 500
    }

    # Allow Windows to release add-in handles, but do not leave enough time
    # for a normal user restart to race the atomic folder replacement.
    Start-Sleep -Milliseconds 350
    if (@(Get-Process -Name "Revit" -ErrorAction SilentlyContinue).Count -gt 0) {
        Write-UpdateLog "A Revit process restarted before installation; waiting again."
        while (@(Get-Process -Name "Revit" -ErrorAction SilentlyContinue).Count -gt 0) {
            Start-Sleep -Milliseconds 500
        }
    }

    Write-UpdateLog "All Revit processes are closed. Installing staged files."
    New-Item -ItemType Directory -Path $TargetAddinsRoot -Force | Out-Null
    if (Test-Path -LiteralPath $targetFolder) {
        Move-Item -LiteralPath $targetFolder -Destination $backupFolder
        $folderBackedUp = $true
    }
    if (Test-Path -LiteralPath $targetManifest) {
        Move-Item -LiteralPath $targetManifest -Destination $backupManifest
        $manifestBackedUp = $true
    }

    Copy-Item -LiteralPath $sourceFolder -Destination $targetFolder -Recurse -Force
    Copy-Item -LiteralPath $sourceManifest -Destination $targetManifest -Force
    Write-UpdateLog "RA BIM $Version installed successfully."

    if ($folderBackedUp -and (Test-Path -LiteralPath $backupFolder)) {
        Remove-Item -LiteralPath $backupFolder -Recurse -Force
    }
    if ($manifestBackedUp -and (Test-Path -LiteralPath $backupManifest)) {
        Remove-Item -LiteralPath $backupManifest -Force
    }

    Show-Result "RA BIM Update" "RA BIM $Version was installed successfully.`n`nOpen Revit to use the new version." $false
}
catch {
    $failure = $_.Exception.Message
    Write-UpdateLog "FAILED: $failure"

    try {
        if (Test-Path -LiteralPath $targetFolder) {
            Remove-Item -LiteralPath $targetFolder -Recurse -Force
        }
        if ($folderBackedUp -and (Test-Path -LiteralPath $backupFolder)) {
            Move-Item -LiteralPath $backupFolder -Destination $targetFolder
        }
        if (Test-Path -LiteralPath $targetManifest) {
            Remove-Item -LiteralPath $targetManifest -Force
        }
        if ($manifestBackedUp -and (Test-Path -LiteralPath $backupManifest)) {
            Move-Item -LiteralPath $backupManifest -Destination $targetManifest
        }
        Write-UpdateLog "Rollback completed."
    }
    catch {
        Write-UpdateLog "Rollback also failed: $($_.Exception.Message)"
    }

    Show-Result "RA BIM Update Failed" "$failure`n`nLog:`n$LogPath" $true
    exit 1
}
finally {
    if (Test-Path -LiteralPath $workRoot) {
        Remove-Item -LiteralPath $workRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
